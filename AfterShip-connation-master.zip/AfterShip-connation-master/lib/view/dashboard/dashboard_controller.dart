import 'package:aftership_mvvm/view_model/controller/common_controller.dart';

class DashboardController extends CommonController {}
