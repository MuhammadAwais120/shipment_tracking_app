import 'package:aftership_mvvm/view_model/controller/common_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AddShipController extends CommonController {
  TextEditingController trackingNoController = TextEditingController();
  TextEditingController courierController = TextEditingController();
  TextEditingController titleController = TextEditingController();
  TextEditingController emailTrackingController = TextEditingController();
}
