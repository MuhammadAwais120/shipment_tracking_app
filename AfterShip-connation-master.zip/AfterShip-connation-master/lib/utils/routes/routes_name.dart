class RoutesName {
  static const String splash = '/splash';
  static const String login = '/login';
  static const String otpScreen = '/otpScreen';
  static const String mainScreen = '/mainScreen';
  static const String addShipment = '/addShipment';
  static const String syncShipment = '/syncShipment';
  static const String accountScreen = '/accountScreen';
  static const String shipmentScreen = '/shipmentScreen';
  static const String dashboardScreen = '/dashboardScreen';
}
