class Konst {
  static String baseUrl = 'https://hfrdhglcbnphvieobsbj.supabase.co';
  static String token =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhmcmRoZ2xjYm5waHZpZW9ic2JqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDY3ODk5NDQsImV4cCI6MjAyMjM2NTk0NH0.zdSIClZH_O0TVI86VTMJlRJe3SXWRPpvoN7Z_r8nkm8';
}
