import 'package:get/get.dart';

class CommonController extends GetxController {
}
