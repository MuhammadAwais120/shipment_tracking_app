package com.example.aftership_mvvm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
